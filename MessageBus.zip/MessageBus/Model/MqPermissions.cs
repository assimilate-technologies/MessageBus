﻿namespace MessageBus
{
    public class MqPermissions
    {
        public string configure { get; set; }
        public string write { get; set; }
        public string read { get; set; }
    }
}