﻿namespace MessageBus
{
    public class MqUser
    {
        public string password { get; set; }
        public string tags { get; set; }
        
    }
}