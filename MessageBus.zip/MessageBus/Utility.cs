﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;
using System.Threading;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;
using System.Net;
using Newtonsoft.Json;

namespace MessageBus
{
    public static class Utility
    {
        public static async Task<string> CreateUserIfNotFound()
        {
            string result = "Success";
            var hostName = Utility.GetMQHost();
            var userName = Utility.GetMQUser();
            var password = Utility.GetMQPassword();
            var port = Utility.GetMQPortNumber();

            try
            {
                // Set MQ server credentials
                NetworkCredential networkCredential = new NetworkCredential("guest", "guest");

                // Instantiate HttpClientHandler, passing in the NetworkCredential
                HttpClientHandler httpClientHandler = new HttpClientHandler { Credentials = networkCredential };

                // Instantiate HttpClient passing in the HttpClientHandler
                using HttpClient httpClient = new HttpClient(httpClientHandler);

                // Get the response from the API endpoint.
                HttpResponseMessage httpResponseMessage = await httpClient.GetAsync("http://"+ hostName +":"+ port +"/api/users/");

                // Get the response content.
                HttpContent httpContent =  httpResponseMessage.Content;

                // Get the stream of the content.
                using StreamReader streamReader = new StreamReader(await httpContent.ReadAsStreamAsync());

                // Get the output string.
                string returnedJsonString = await streamReader.ReadToEndAsync();

                // Instantiate a list to loop through.
                List<string> mqAccountNames = new List<string>();

                if (returnedJsonString != "")
                {
                    // Deserialize into object
                    dynamic dynamicJson = JsonConvert.DeserializeObject(returnedJsonString);
                    if (dynamicJson != null)
                    {
                        foreach (dynamic item in dynamicJson)
                        {
                            mqAccountNames.Add(item.name.ToString());
                        }
                    }
                }

                bool accountExists = false;

                foreach (string mqAccountName in mqAccountNames)
                {
                    if (mqAccountName == userName)
                    {
                        accountExists = true;
                    }
                }

                switch (accountExists)
                {
                    case true:
                        result = "This user already exists on the MQ server.";
                        break;
                    case false:
                        // Create the new user on the MQ Server

                        string uri = $"http://"+ hostName +":"+ port +"/api/users/"+userName+"";

                        MqUser mqUser = new MqUser
                        {
                            password = password,
                            tags = "administrator"
                        };

                        string info = JsonConvert.SerializeObject(mqUser);
                        StringContent content = new StringContent(info, Encoding.UTF8, "application/json");

                        httpResponseMessage = await httpClient.PutAsync(uri, content);
                        if (!httpResponseMessage.IsSuccessStatusCode)
                        {
                            result= "There was an error creating the MQ user account.";
                            
                        }

                        uri = $"http://"+ hostName +":"+ port +"/api/permissions/%2F/"+userName+"";

                        MqPermissions mqPermissions = new MqPermissions
                        {
                            configure = ".*",
                            write = ".*",
                            read = ".*"
                        };

                        info = JsonConvert.SerializeObject(mqPermissions);
                        content = new StringContent(info, Encoding.UTF8, "application/json");

                        httpResponseMessage = await httpClient.PutAsync(uri, content);

                        if (!httpResponseMessage.IsSuccessStatusCode)
                        {
                            result= "There was an error creating the permissions on the MQ user account.";
                        }

                        break;
                }
            }
            catch (Exception e)
            {
                result = e.Message;
            }

            return result;
        }

        public static string GetMQHost()
        {
            var hostName = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build().GetSection("MQConfig")["HostName"];
            return hostName;
        }

        public static string GetMQUser()
        {
            var hostName = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build().GetSection("MQConfig")["User"];
            return hostName;
        }

        public static string GetMQPassword()
        {
            var hostName = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build().GetSection("MQConfig")["Password"];
            return hostName;
        }

        public static int GetMQPortNumber()
        {
            var hostName = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build().GetSection("MQConfig")["PortNumber"];
            return !string.IsNullOrEmpty(hostName) ? Convert.ToInt32(hostName) : 0;
        }

    }

   
}
