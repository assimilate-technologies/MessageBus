﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MessageBus
{
    public class PublisherFactory
    {


        public IPublisher GetPublisher(string brokerType = "")
        {
            if (!string.IsNullOrEmpty(brokerType) && brokerType.ToLower().Trim() == "rabbitmq")
            {
                return new MQSender();
            }
           
            throw new Exception("Only RabbitMQ broker is available.");
        }
    }
}
