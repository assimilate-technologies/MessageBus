﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MessageBus
{
    public class ConsumerFactory
    {
        public IConsumer GetConsumer(string brokerType = "")
        {
            if (!string.IsNullOrEmpty(brokerType) && brokerType.ToLower().Trim() == "rabbitmq")
            {
                return new MQReceiver();
            }
            
            throw new Exception("Only RabbitMQ broker is available.");
        }
    }
}
