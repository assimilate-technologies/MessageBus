﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;
using System.Threading;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;
namespace MessageBus
{
    internal class MQSender:IPublisher
    {
        public string PublishMessage(string messageQueueName = "", string messageBody = "")
        {
            string result = "Success";
            var hostName = Utility.GetMQHost();
            var user = Utility.GetMQUser();
            var password = Utility.GetMQPassword();
            var port = Utility.GetMQPortNumber();

            

            if (string.IsNullOrEmpty(hostName))
                return "Host Name is required.";
            if (port==0)
                return "Port Number is required.";
            if (string.IsNullOrEmpty(user))
                return "User Name is required.";
            if (string.IsNullOrEmpty(password))
                return "Password is required.";
            if (string.IsNullOrEmpty(messageQueueName))
                return "Message Queue Name is required.";
            
            if (string.IsNullOrEmpty(messageBody))
                return "Message Body is required.";
            try
            {
                var factory = new ConnectionFactory()
                {
                    HostName = hostName
                };


                using (var connection = factory.CreateConnection())
                using (var channel = connection.CreateModel())
                {
                  QueueDeclareOk qdo =  channel.QueueDeclare(queue: messageQueueName,
                                         durable: false,
                                         exclusive: false,
                                         autoDelete: false,
                                         arguments: null);

                    
                    var body = Encoding.UTF8.GetBytes(messageBody);

                    //to do error handling
                    channel.BasicPublish(exchange: "",
                                         routingKey: messageQueueName,
                                         basicProperties: null,
                                         body: body);
                   
                }
                
            }
            catch (Exception ex)
            {
                result = ex.Message;
            }
            

            return result;
        }
    }
}
